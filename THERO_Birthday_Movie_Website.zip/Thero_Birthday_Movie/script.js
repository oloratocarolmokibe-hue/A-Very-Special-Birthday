const login = document.getElementById("loginScreen");
const movie = document.getElementById("movie");
const password = document.getElementById("password");
const loginBtn = document.getElementById("loginBtn");
const error = document.getElementById("error");
const music = document.getElementById("music");
const musicBtn = document.getElementById("musicBtn");

/* Change the password here if you want a different one. */
const SECRET_PASSWORDS = ["love", "baby", "spiderman", "thero"];

function unlock(){
  const value = password.value.trim().toLowerCase();
  if(SECRET_PASSWORDS.includes(value)){
    login.classList.add("hidden");
    movie.classList.remove("hidden");
    document.body.style.overflowY = "auto";
    music.play().then(()=>musicBtn.classList.add("playing")).catch(()=>{});
    window.scrollTo(0,0);
  }else{
    error.style.display = "block";
    password.animate([
      {transform:"translateX(0)"},{transform:"translateX(-8px)"},
      {transform:"translateX(8px)"},{transform:"translateX(0)"}
    ],{duration:280});
  }
}
loginBtn.addEventListener("click",unlock);
password.addEventListener("keydown",e=>{if(e.key==="Enter")unlock()});

musicBtn.addEventListener("click",()=>{
  if(music.paused){
    music.play();
    musicBtn.classList.add("playing");
  }else{
    music.pause();
    musicBtn.classList.remove("playing");
  }
});

function scrollToId(id){
  document.getElementById(id).scrollIntoView({behavior:"smooth"});
}

document.body.style.overflow = "hidden";
