# THERO — Birthday Movie Website ❤️

## How to open it
1. Extract the ZIP.
2. Open `index.html` in Chrome, Edge, Firefox, or Safari.
3. The secret passwords currently accepted are:
   - love
   - baby
   - spiderman
   - thero

## Add your photos
Put your photos inside the `images` folder and name them:
- hero.jpg
- final.jpg
- photo1.jpg
- photo2.jpg
- photo3.jpg
- photo4.jpg
- photo5.jpg
- photo6.jpg
- photo7.jpg
- photo8.jpg

JPG, JPEG, and PNG all work, but keep the names matching the HTML.

## Add your song
Put an MP3 file inside the `music` folder and name it:
`song.mp3`

The music starts after the password is accepted. Some browsers may require the first click/tap before audio can play; the login button provides that interaction.

## Change the password
Open `script.js` and edit:
const SECRET_PASSWORDS = ["love", "baby", "spiderman", "thero"];

## Personalise it
The long birthday letter, poem, captions, title and credits are all in `index.html`.
